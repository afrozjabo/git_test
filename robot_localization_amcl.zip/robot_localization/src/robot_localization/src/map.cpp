#include <iostream>
#include <ros/ros.h>
#include <tf/tf.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Odometry.h>
#include <opencv2/opencv.hpp>
#include "robot_localization/pose.h"
#include "robot_localization/point.h"
#include <std_msgs/Float64.h>
#include <std_msgs/String.h>
#include <math.h>
#include <algorithm>
#include <random>
#include <numeric>

using namespace std;

bool set_particle = false;

ros::Publisher pub;
ros::Publisher laser_pub;

int total_sample_number;

cv::Mat dist_map;
// map information
double map_resolution;
robot_localization::pose map_origin;
int map_width, map_height;
bool got_map;
int obstacle_number;

// laserScan information
vector<float> ranges;
double angle_min, angle_max, angle_increment, range_min, range_max, scan_time;
double free_space_min_x, free_space_max_x, free_space_min_y, free_space_max_y;

// robot initial position at time zero;
geometry_msgs::PoseWithCovariance initial_pose;

//particle defintion
class particle
{
public:
    int id;
    double x;
    double y;
    double theta;
    double weight;

    void set_particle(double x, double y, double theta = 0.0, double weight = 1)
    {
        x = x;
        y = y;
        theta = theta;
        weight = weight;
    }
};
sensor_msgs::LaserScan laser_msg;
float closest;
float second_closest;

nav_msgs::Odometry odom_data;
bool is_initialized = true;

vector<particle> estimate_pose;
float thresold = map_resolution / 10.0;


void my_sensor_function(const sensor_msgs::LaserScan::ConstPtr &msg);
void my_odom_function(const nav_msgs::Odometry::ConstPtr &msg);
void set_particle_function();
void particle_update(vector<particle> &estimate_pose, nav_msgs::Odometry &odom_data, sensor_msgs::LaserScan &laser_msg);
void exact_pose(vector<particle>&estimate_pose);


void xy2uv(int &u, int &v, double x, double y)
{
    // dx and dy is co-ordinate distance between map_origin and point x,y in map with respect to global co-ordinate.
    double dx = x - map_origin.getX();
    double dy = y - map_origin.getY();
    double yaw = -map_origin.getYaw();

    // xx and yy is co-ordinates of point w.r.t map co-ordinate
    double xx = dx * cos(yaw) - dy * sin(yaw);
    double yy = dx * sin(yaw) + dy * cos(yaw);
    // u and v is cell_no. of grid map.
    u = (int)(xx / map_resolution);
    v = (int)(yy / map_resolution);
}

void uv2xy(int u, int v, double &x, double &y)
{
    double xx = (double)u * map_resolution;
    double yy = (double)v * map_resolution;
    double yaw = map_origin.getYaw();
    double dx = xx * cos(yaw) - yy * sin(yaw);
    double dy = xx * sin(yaw) + yy * cos(yaw);
    x = dx + map_origin.getX();
    y = dy + map_origin.getY();
}

int xy2node(double x, double y)
{
    int u, v;
    xy2uv(u, v, x, y);
    if (0 <= u && u < map_width && 0 <= v && v < map_height)
        return v * map_width + u;
    else
        return -1;
}

bool is_on_map(int &u, int &v)
{
    if (v >= 0 && u >= 0 && v < map_height && u < map_width)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// vector<vector<double>> both_shortest_dist;

double both_shortest_dist[392][441];

void second_shortest_dist(cv::Mat distance_map, cv::Mat binMap, double both_shortest_dist[392][441], int map_height, int map_width)
{

    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {

            if (binMap.at<float>(v, u) == 0)
            {
                both_shortest_dist[v][u] = 0;
                break;
            }
            double second_distance = 1000;
            double radius = distance_map.at<float>(v, u);
            double x, y;
            uv2xy(u, v, x, y);

            double radius_s = radius;
            int count = 0;
            while (radius_s < range_max)
            {

                bool find_shortest = false;

                radius_s += map_resolution;

                for (double theta = 0; theta < 3.1414;)
                {
                    count++;
                    double r_x = x + radius_s * cos(theta);
                    double r_y = y + radius_s * sin(theta);

                    int r_u;
                    int r_v;

                    xy2uv(r_u, r_v, r_x, r_y);

                    int u_s;
                    int v_s;
                    double x_s = x + radius * cos(theta);
                    double y_s = y + radius * sin(theta);
                    xy2uv(u_s, v_s, x_s, y_s);

                    if (is_on_map(r_u, r_v))
                    {
                        if (binMap.at<uchar>(r_v, r_u) == 0 && binMap.at<uchar>(v_s, u_s) != 0)
                        {
                            find_shortest = true;
                            both_shortest_dist[v][u] = (radius_s);
                            break;
                        }
                        if (find_shortest)
                        {
                            break;
                        }
                    }
                    theta = (theta + angle_increment);
                }
                if (find_shortest)
                {
                    break;
                }
            }
        }
    }
}

nav_msgs::OccupancyGrid map_;
cv::Mat distance_map(map_height, map_width, CV_32FC1);
void my_map_function(const nav_msgs::OccupancyGrid::ConstPtr &msg)
{
    cout << "this is my map function";
    map_ = *msg;
    map_width = msg->info.width;
    map_height = msg->info.height;
    map_resolution = msg->info.resolution;

    tf::Quaternion q(msg->info.origin.orientation.x,
                     msg->info.origin.orientation.y,
                     msg->info.origin.orientation.z,
                     msg->info.origin.orientation.w);
    double roll, pitch, yaw;

    tf::Matrix3x3 m(q);
    m.getRPY(roll, pitch, yaw);
    map_origin.setX(msg->info.origin.position.x);
    map_origin.setY(msg->info.origin.position.y);
    map_origin.setYaw(yaw);

    cv::Mat binMap(map_height, map_width, CV_8UC1);

    bool isFirst = true;

    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {
            int node = v * map_width + u;
            int val = msg->data[node];

            if (val == 100)
            {
                binMap.at<uchar>(v, u) = 0;
            }
            else
            {
                binMap.at<uchar>(v, u) = 1;
                if (val == 0)
                {
                    double x, y;
                    uv2xy(u, v, x, y);
                    if (isFirst)
                    {

                        free_space_min_x = free_space_max_x = x;
                        free_space_min_y = free_space_max_y = y;

                        isFirst = false;
                    }
                    else
                    {
                        if (free_space_min_x > x)
                            free_space_min_x = x;

                        if (free_space_max_x < x)
                            free_space_max_x = x;

                        if (free_space_min_y > y)
                            free_space_min_y = y;

                        if (free_space_max_y < y)
                            free_space_max_y = y;
                    }
                }
            }
        }
    }
    cv::Mat ss_dist_map(map_height, map_width, CV_32FC1);
    cv::Mat distance_map1(map_height, map_width, CV_32FC1);
    cv::distanceTransform(binMap, dist_map, cv::DIST_L2, 5);
    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {
            double theta = 0;

            float d = dist_map.at<float>(v, u) * (float)map_resolution;

            distance_map1.at<float>(v, u) = d;
        }
    }
    distance_map = distance_map1;
    got_map = true;
    second_shortest_dist(distance_map, binMap, both_shortest_dist, map_height, map_width);
    //for threading
    ros::NodeHandle n;
    if(got_map){
    ros::Subscriber sub_sensor=n.subscribe("/scan", 1000, my_sensor_function);
    got_map=false;
    if(!set_particle){
    set_particle_function();
    set_particle = true;

    }
    ros::Subscriber sub_odom = n.subscribe("/odom", 1000, my_odom_function);
    ros::Subscriber sub_sensor1 = n.subscribe("/scan", 1000, my_sensor_function);
    particle_update(estimate_pose,odom_data,laser_msg);

}
//
}


void closest_second_closest(vector<float> ranges, float &closest, float &second_closest)
{

    for (int count = 0; count < 2; count++)
    {
        float smallest = 2000;

        for (int i = count; i < ranges.size(); i++)
        {
            if (smallest > ranges[i])
                smallest = ranges[i];
        }
        ranges[count] = smallest;
        count += 1;
    }
    closest = ranges[0];
    second_closest = ranges[1];
}
// this call_back function for sensor subscribe the topic /scan.


void my_sensor_function(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    sensor_msgs::LaserScan laser_msg = *msg;
    angle_increment = msg->angle_increment;
    range_min = msg->range_min;
    range_max = msg->range_max;
    scan_time = msg->scan_time;
    ranges = msg->ranges;
    std_msgs::String st;
    // float closest;
    // float second_closest;

    closest_second_closest(ranges, closest, second_closest);
    st.data = to_string(closest) + "--" + to_string(second_closest);
    laser_pub.publish(st);
}


// this is for odom messages
// nav_msgs::Odometry odom_data;
// bool is_initialized = true;
void my_odom_function(const nav_msgs::Odometry::ConstPtr &msg)
{

    odom_data = *msg;

    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();

    double change_time = current_time.toSec() - last_time.toSec();
    double th = msg->twist.twist.angular.z * change_time;
    double change_x = (msg->twist.twist.linear.x * cos(th) - msg->twist.twist.linear.y * sin(th)) * change_time;
    double change_y = (msg->twist.twist.linear.x * sin(th) + msg->twist.twist.linear.y * cos(th)) * change_time;

    double yaw = msg->pose.pose.orientation.z;
}


// vector<particle> estimate_pose;
// float thresold = map_resolution / 10.0;
void set_particle_function()
{

    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {
            if (abs(distance_map.at<float>(v, u) - closest) <= thresold && abs(both_shortest_dist[v][u] - second_closest) <= thresold)
            {
                double x, y;
                uv2xy(u, v, x, y);
                particle p;
                p.set_particle(x, y);
                estimate_pose.push_back(p);
            }
        }
    }
}

void particle_update(vector<particle> &estimate_pose, nav_msgs::Odometry &odom_data, sensor_msgs::LaserScan &laser_msg)
{

    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();

    double change_time = current_time.toSec() - last_time.toSec();
    double th = odom_data.twist.twist.angular.z * change_time;
    double change_x = (odom_data.twist.twist.linear.x * cos(th) - odom_data.twist.twist.linear.y * sin(th)) * change_time;
    double change_y = (odom_data.twist.twist.linear.x * sin(th) + odom_data.twist.twist.linear.y * cos(th)) * change_time;

    for (auto pose : estimate_pose)
    {
        pose.set_particle((pose.x + change_x), (pose.y + change_y));
        int u, v;
        xy2uv(u, v, pose.x, pose.y);

        if (abs(distance_map.at<float>(v, u) - closest) <= thresold && abs(both_shortest_dist[v][u] - second_closest) <= thresold)
        {
            pose.weight=pose.weight + 1;
        }
    }
    exact_pose(estimate_pose);
}

void exact_pose(vector<particle>&estimate_pose){
    particle true_pose;
    for(auto pose:estimate_pose){
        if(pose.weight>true_pose.weight){
            true_pose = pose;
            std_msgs::String s;
            s.data = to_string(true_pose.x) + ".." + to_string(true_pose.y);
            pub.publish(s);
        }
    }
    set_particle = false;
}

int main(int argc, char **argv)
{

    ros::init(argc, argv, "my_map");

    ros::NodeHandle nh;

    pub = nh.advertise<std_msgs::String>("my_chatter", 1000);

    laser_pub = nh.advertise<std_msgs::String>("laser_scan", 1000);

    ros::Subscriber sub = nh.subscribe("/map", 1000, my_map_function);
    // ros::Subscriber sub_odom = nh.subscribe("/odom", 1000, my_odom_function);
    // ros::Subscriber sub_sensor = nh.subscribe("/scan", 1000, my_sensor_function);

    ros::spin();

    return 0;
}
