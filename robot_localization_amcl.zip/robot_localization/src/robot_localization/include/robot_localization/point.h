#ifndef __point__H__
#define __point__H__

namespace robot_localization{
    class point{
        private:
        double x_i,y_i;
        public:
        //point constructor
        point():x_i(0.0),y_i(0.0){}
        point(double x,double y):x_i(x),y_i(y){}

        //point destructor
        ~point() {};

        //set point value
        inline void setX(double x) { x_i = x; }
        inline void setY(double y) { y_i = y; }
        inline void setPoint(double x, double y) { x_i = x, y_i = y; }
        inline void setPoint(point p) { x_i = p.x_i, y_i = p.y_i; }

        //get point value
        inline double getX(void) { return x_i; }
        inline double getY(void) { return y_i; }
        inline point getPoint(void) { return point(x_i, y_i); }

        
    };
}

#endif