#ifndef __pose__H__
#define __pose__H__
#include<cmath>
namespace robot_localization{

    class pose{
        private:
        double x_i,y_i,yaw_i;

        void modifyYaw(void) {
            while (yaw_i < -M_PI)
                yaw_i+= 2.0 * M_PI;
            while (yaw_i > M_PI)
                yaw_i -= 2.0 * M_PI;
        }   

        public:
        //constructor
        pose():x_i(0.0),y_i(0.0),yaw_i(0.0){};
        pose(double x,double y,double yaw):x_i(x),y_i(y),yaw_i(yaw){};

        //pose destructor
        // ~pose();

        //set position of robot
        inline void setX(double x) { x_i = x; }
        inline void setY(double y) { y_i = y; }
        inline void setYaw(double yaw) { yaw_i = yaw, modifyYaw(); }
        inline void setPose(double x, double y, double yaw) { x_i = x, y_i = y, yaw_i = yaw, modifyYaw(); }
        inline void setPose(pose p) { x_i = p.x_i, y_i = p.y_i, yaw_i = p.yaw_i, modifyYaw(); }

        //get pose of robot
        inline double getX(void) { return x_i; }
        inline double getY(void) { return y_i; }
        inline double getYaw(void) { return yaw_i; }
        inline pose getPose(void) { return pose(x_i, y_i, yaw_i); }

       
    };
}




#endif