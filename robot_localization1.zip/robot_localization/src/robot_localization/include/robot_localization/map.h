#ifndef map
#define map
#include<iostream>
#include<ros/ros.h>
#include<tf/tf.h>
#include<sensor_msgs/LaserScan.h>
#include<nav_msgs/OccupancyGrid.h>
#include<opencv2/opencv.hpp>
#include"robot_localization/pose.h"


namespace map{
    class obstacle {
        public:
        double x,y,s;

        obstacle():x(0.0),y(0.0),s(1.0){}
        obstacle(double x, double y,double s):x(x),y(y),s(s){}
    };

    class map_data{
        private:
            ros::NodeHandle nh;
            std::string map_name;
            ros::Subscriber map_sub;

            int total_sample_number;
            
            ros::nav_msgs::OccupancyGrid map_;

            cv::Mat dist_map;
            //map information
            double map_resolution;
            pose map_origin;
            int map_width,map_height;
            bool got_map;
            int obstacle_number;
            //laserScan information
            double angle_min,angle_max,angle_increment,range_min,range_max,scan_time,scan_angle_noise,scan_range_noise;
            double free_space_min_x,free_space_max_x,free_space_min_y,free_space_max_y;
            double valid_scan_rate;

            double positional_error,angular_error;
            double positional_error_max,angular_error_max;



        public:
            map_data():
                nh("~"),
                map_name("/map"),
                total_sample_number(20000),
                obstacle_number(20),
                angle_min(-180),
                angle_max(180),
                angle_increment(.25),
                range_min(.44999),
                range_max(25.0),
                scan_angle_noise(0.01),
                scan_range_noise(0.05),
                got_map(false)
                {

                }
    void map_generation_init(){
        angle_min *= M_PI /180.0;
        angle_max *= M_PI /180.0;
        angle_increment *= M_PI /180.0;
        scan_angle_noise *= M_PI /180.0;
        angular_error *= M_PI /180.0;
        angular_error_max *= M_PI /180.0;

        map_sub = nh.subscribe<nav_msgs::OccupancyGrid>(map_name,1,my_map);
        ros::Rate loopRate(10);
        int cnt = 0;
        while(ros::ok()){
            ros::spinOnce;
            if(got_map){
                break;
            }
            cnt++;
            if(cnt>50){
                exit(1);
            }
            loopRate.sleep();
        }

    }

    void generate_dataset(){
        for(int i = 0; i < total_sample_number; i++)
        {
            std::vector<obstacle>obstacles = generate_obstacle();
        }
    }

    void xy2uv(int u,int v,double *x,double *y) 
    {   
        //dx and dy is co-ordinate distance between map_origin and point x,y in map with respect to global co-ordinate.
        double dx = x - map_origin.getX();
        double dy = y - map_origin.getY();
        double yaw = -map_origin.getYaw();

        //xx and yy is co-ordinates of point w.r.t map co-ordinate
        double xx = dx * cos(yaw) - dy * sin(yaw);
        double yy = dx * sin(yaw) + dy * cos(yaw);
        // u and v is cell_no. of grid map.
        *u = (int)(xx / map_resolution);
        *v = (int)(yy / map_resolution);

    }

    void uv2xy(int u,int v,double *x,double *y){
        double xx = (double)u * map_resolution;
        double yy = (double)v * map_resolution;
        double yaw = map_origin.getYaw();
        double dx = xx * cos(yaw) - yy * sin(yaw);
        double dy = xx * sin(yaw) + yy * cos(yaw);
        *x = dx + map_origin.getX();
        *y = dy + map_origin.getY();
    }

    int xy2node(double x, double y){
        int u, v;
        xy2uv(x,y,&u,&v);
        if(0 <= u && u < map_width && 0 <= v && v < map_height)
            return  v * map_width + u;
        else
            return -1;
    }


    void my_map(const nav_msgs::OccupancyGrid::ConstPtr &msg){
        map_ = *msg;
        map_width = msg->info.width;
        map_height= msg->info.height;
        map_resolution = msg->info.resolution;

        tf::Quaternion q(msg->info.origin.orientation.x, 
            msg->info.origin.orientation.y, 
            msg->info.origin.orientation.z,
            msg->info.origin.orientation.w);
        double roll,pitch,yaw;

        tf::Matrix3x3 m(q);
        m.getRPY(roll,pitch,yaw);
        map_origin.setX(msg->info.origin.position.x);
        map_origin.sety(msg->info.origin.position.y);
        map_origin.setYaw(yaw);

        cv::Mat binMap(map_height,map_width,CV_8UC1);

        bool isFirst = true;

        for(int v = 0; v < map_height; v++)
        {
            for(int u = 0; u < map_width; u++)
            {
                int node = v * map_width + u;
                int val = msg->data[node];

                if(val == 100){
                    binMap.at<uchar>(v,u) = 0;
                }
                else{
                    binMap.at<v,u> = 1;
                    if(val==0){
                        double x,y;
                        if(isFirst){
                            free_space_min_x = free_space_max_x = x;
                            free_space_min_y = free_space_max_y = y;
                            isFirst = false;
                        }
                        else{
                            if(free_space_min_x > x)
                                free_space_min_x = x;
                            
                            if(free_space_max_x < x)
                                free_space_max_x = x;
                            
                            if(free_space_min_y > y)
                                free_space_min_y = y;
                            
                            if(free_space_max_y < y)
                                free_space_max_y = y;
                            
                        }
                    }
                }

            }
        }
        cv::Mat distance_map(map_height,map_width,CV_32FC1);
        cv::distanceTransform(binMap,dist_map,cv::DIST_L2,5);
        for(int v = 0; v < map_height; v++){
            for(int u = 0; u < map_width; u++)
            {
                float d = dist_map.at<float>(v,u) * (float)map_resolution;
                dist_map.at<float>(v,u) = d;
            }
        }
        got_map = true;
    } 
    std::vector<obstacle> generate_obstacle(){
        std::vector<obstacle>obstacles(obstacle_number);
        for(int i = 0; i < obstacle_number; ++i)
        {
            obstacles[i].x = urand(free_space_min_x,free_space_max_x);
            obstacles[i].y = urand(free_space_min_y,free_space_max_y);
            obstacles[i].s = 1.0 + nrand(0.5);

        }
        return obstacles;
    }
 };

}


#endif
