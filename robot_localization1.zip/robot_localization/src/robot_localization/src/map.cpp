#include <iostream>
#include <ros/ros.h>
#include <tf/tf.h>
#include <sensor_msgs/LaserScan.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Odometry.h>
#include <opencv2/opencv.hpp>
#include "robot_localization/pose.h"
#include "robot_localization/point.h"
#include <std_msgs/Float64.h>
#include <std_msgs/String.h>
#include<math.h>
#include<algorithm>
#include<random>
#include<numeric>

using namespace std;

ros::Publisher pub;
ros::Publisher laser_pub;

int total_sample_number;

cv::Mat dist_map;

// map information
double map_resolution;
robot_localization::pose map_origin;
int map_width, map_height;
bool got_map;
int obstacle_number;

// laserScan information
vector<float> ranges;
double angle_min, angle_max, angle_increment, range_min, range_max, scan_time;
double free_space_min_x, free_space_max_x, free_space_min_y, free_space_max_y;


// robot initial position at time zero;
geometry_msgs::PoseWithCovariance initial_pose;

// namespace map{
//     class obstacle {
//         public:
//         double x,y,s;

//         obstacle():x(0.0),y(0.0),s(1.0){}
//         obstacle(double x, double y,double s):x(x),y(y),s(s){}
//     };

//     class map_data{
//         private:
//             ros::NodeHandle nh;
//             std::string map_name;
//             ros::Subscriber map_sub;

//             int total_sample_number;

//             ros::nav_msgs::OccupancyGrid map_;

//             cv::Mat dist_map;
//             //map information
//             double map_resolution;
//             pose map_origin;
//             int map_width,map_height;
//             bool got_map;
//             int obstacle_number;
//             //laserScan information
//             double angle_min,angle_max,angle_increment,range_min,range_max,scan_time,scan_angle_noise,scan_range_noise;
//             double free_space_min_x,free_space_max_x,free_space_min_y,free_space_max_y;
//             double valid_scan_rate;

//             double positional_error,angular_error;
//             double positional_error_max,angular_error_max;

//         public:
//             map_data():
//                 nh("~"),
//                 map_name("/map"),
//                 total_sample_number(20000),
//                 obstacle_number(20),
//                 angle_min(-180),
//                 angle_max(180),
//                 angle_increment(.25),
//                 range_min(.44999),
//                 range_max(25.0),
//                 scan_angle_noise(0.01),
//                 scan_range_noise(0.05),
//                 got_map(false)
//                 {

//                 }
//     void map_generation_init(){
//         angle_min *= M_PI /180.0;
//         angle_max *= M_PI /180.0;
//         angle_increment *= M_PI /180.0;
//         scan_angle_noise *= M_PI /180.0;
//         angular_error *= M_PI /180.0;
//         angular_error_max *= M_PI /180.0;

//         map_sub = nh.subscribe<nav_msgs::OccupancyGrid>(map_name,1,my_map);
//         ros::Rate loopRate(10);
//         int cnt = 0;
//         while(ros::ok()){
//             ros::spinOnce;
//             if(got_map){
//                 break;
//             }
//             cnt++;
//             if(cnt>50){
//                 exit(1);
//             }
//             loopRate.sleep();
//         }

//     }

//     void generate_dataset(){
//         for(int i = 0; i < total_sample_number; i++)
//         {
//             std::vector<obstacle>obstacles = generate_obstacle();
//         }
//     }



void xy2uv(int &u, int &v, double x, double y)
{
    // dx and dy is co-ordinate distance between map_origin and point x,y in map with respect to global co-ordinate.
    double dx = x - map_origin.getX();
    double dy = y - map_origin.getY();
    double yaw = -map_origin.getYaw();

    // xx and yy is co-ordinates of point w.r.t map co-ordinate
    double xx = dx * cos(yaw) - dy * sin(yaw);
    double yy = dx * sin(yaw) + dy * cos(yaw);
    // u and v is cell_no. of grid map.
    u = (int)(xx / map_resolution);
    v = (int)(yy / map_resolution);
}

void uv2xy(int u, int v, double &x, double &y)
{
    double xx = (double)u * map_resolution;
    double yy = (double)v * map_resolution;
    double yaw = map_origin.getYaw();
    double dx = xx * cos(yaw) - yy * sin(yaw);
    double dy = xx * sin(yaw) + yy * cos(yaw);
    x = dx + map_origin.getX();
    y = dy + map_origin.getY();
}

int xy2node(double x, double y)
{
    int u, v;
    xy2uv(u, v, x, y);
    if (0 <= u && u < map_width && 0 <= v && v < map_height)
        return v * map_width + u;
    else
        return -1;
}

bool is_on_map(int &u, int &v)
{
    if (v >= 0 && u >= 0 && v < map_height && u < map_width)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// vector<vector<double>> both_shortest_dist;

double both_shortest_dist[392][441];

void second_shortest_dist(cv::Mat distance_map, cv::Mat binMap, double both_shortest_dist[392][441], int map_height, int map_width)
{

    // range_max = 25;
    // angle_increment = .34;
    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {

            if (binMap.at<float>(v, u) == 0)
            {
                both_shortest_dist[v][u] = 0;
                break;
            }
            double second_distance = 1000;
            double radius = distance_map.at<float>(v, u);
            double x, y;
            uv2xy(u, v, x, y);

            double radius_s = radius;
            int count = 0;
            while (radius_s < range_max)
            {

                bool find_shortest = false;

                radius_s += map_resolution;

                for (double theta = 0; theta < 3.1414;)
                {
                    count++;
                    double r_x = x + radius_s * cos(theta);
                    double r_y = y + radius_s * sin(theta);

                    int r_u;
                    int r_v;

                    xy2uv(r_u, r_v, r_x, r_y);

                    int u_s;
                    int v_s;
                    double x_s = x + radius * cos(theta);
                    double y_s = y + radius * sin(theta);
                    xy2uv(u_s, v_s, x_s, y_s);

                    if (is_on_map(r_u, r_v))
                    {
                        if (binMap.at<uchar>(r_v, r_u) == 0 && binMap.at<uchar>(v_s, u_s) != 0)
                        {
                            find_shortest = true;
                            // both_shortest_dist[v][u] = radius_s;
                            both_shortest_dist[v][u] = (radius_s);
                            std_msgs::String s;
                            s.data = to_string(v)+"--" +to_string(u)+"---"+to_string(radius_s);
                            pub.publish(s);
                            break;
                        }
                        if (find_shortest)
                        {
                            break;
                        }
                    }
                    theta = (theta + angle_increment);
                }
                if (find_shortest)
                {
                    break;
                }
            }
        }
    }
}

void my_map_function(const nav_msgs::OccupancyGrid::ConstPtr &msg)
{
    cout << "this is my map function";
    map_ = *msg;
    map_width = msg->info.width;
    map_height = msg->info.height;
    map_resolution = msg->info.resolution;

    tf::Quaternion q(msg->info.origin.orientation.x,
                     msg->info.origin.orientation.y,
                     msg->info.origin.orientation.z,
                     msg->info.origin.orientation.w);
    double roll, pitch, yaw;

    tf::Matrix3x3 m(q);
    m.getRPY(roll, pitch, yaw);
    map_origin.setX(msg->info.origin.position.x);
    map_origin.setY(msg->info.origin.position.y);
    map_origin.setYaw(yaw);

    cv::Mat binMap(map_height, map_width, CV_8UC1);

    bool isFirst = true;

    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {
            int node = v * map_width + u;
            int val = msg->data[node];

            if (val == 100)
            {
                binMap.at<uchar>(v, u) = 0;
            }
            else
            {
                binMap.at<uchar>(v, u) = 1;
                if (val == 0)
                {
                    double x, y;
                    uv2xy(u, v, x, y);
                    if (isFirst)
                    {

                        free_space_min_x = free_space_max_x = x;
                        free_space_min_y = free_space_max_y = y;

                        isFirst = false;
                    }
                    else
                    {
                        if (free_space_min_x > x)
                            free_space_min_x = x;

                        if (free_space_max_x < x)
                            free_space_max_x = x;

                        if (free_space_min_y > y)
                            free_space_min_y = y;

                        if (free_space_max_y < y)
                            free_space_max_y = y;
                    }
                }
            }
        }
    }
    cv::Mat ss_dist_map(map_height, map_width, CV_32FC1);
    cv::Mat distance_map(map_height, map_width, CV_32FC1);
    cv::distanceTransform(binMap, dist_map, cv::DIST_L2, 5);
    for (int v = 0; v < map_height; v++)
    {
        for (int u = 0; u < map_width; u++)
        {
            double theta = 0;

            float d = dist_map.at<float>(v, u) * (float)map_resolution;

            distance_map.at<float>(v, u) = d;
        }
    }
    got_map = true;
    second_shortest_dist(distance_map, binMap, both_shortest_dist, map_height, map_width);
}

// this is function for second closest point in map for each cell

// this call_back function for sensor subscribe the topic /scan

nav_msgs::Odometry odom_data;
bool is_initialized = true;

void my_odom_function(const nav_msgs::Odometry::ConstPtr &msg)
{
    double prev_time;
    odom_data = *msg;

    double current_time = msg->header.stamp.toSec();

    if (is_initialized)
    {
        initial_pose = msg->pose;
        prev_time = current_time;
        is_initialized = false;
        return;
    }

    double delta_time = current_time - prev_time;

    if (delta_time == 0.0)
    {
        return;
    }
}

void closest_second_closest(vector<float> ranges,float &closest,float &second_closest)
{
    
    for (int count = 0; count < 2; count++)
    {
        float smallest=2000;

        for (int i = count; i < ranges.size(); i++)
        {
            if (smallest > ranges[i])
                smallest = ranges[i];
        }
       ranges[count]= smallest;
        count+=1;
    }
    closest = ranges[0];
    second_closest = ranges[1];
}
// this call_back function for sensor subscribe the topic /scan.

sensor_msgs::LaserScan laser_msg;
void my_sensor_function(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    sensor_msgs::LaserScan laser_msg = *msg;
    angle_increment = msg->angle_increment;
    range_min = msg->range_min;
    range_max = msg->range_max;
    scan_time = msg->scan_time;
    ranges = msg->ranges;
    std_msgs::String st;
   float closest;
   float second_closest;

    
        closest_second_closest(ranges,closest,second_closest);
        st.data = to_string(closest) + "--" + to_string(second_closest);
        laser_pub.publish(st);


}

//this is for odom messages
nav_msgs::OccupancyGrid odom_data;
bool is_initialized = true;
void my_odom_function(const nav_msgs::OccupancyGrid::ConstPtr& msg){

    map_ = *msg;
    // double prev_time = msg->header.stamp.toSec();
    // double curr_time ;

    // if(is_initialized){
    //     curr_time = prev_time;
    //     is_initialized = false;
    //     return;
    // }
    // if(change_time = 0.0){
    //     return;
    // }

    ros::Time current_time, last_time;
    current_time = ros::Time::now();
    last_time = ros::Time::now();
    

    
    

    change_time = current_time - last_time;

    double change_x = ( msg->twist.twist.linear.x * cos(th) - msg->twist.twist.linear.y * sin(th)) * change_time;
    double change_y =  (msg->twist.twist.linear.x * sin(th) + msg->twist.twist.linear.y * cos(th)) * change_time;
    double change_theta =  msg->twist.twist.angular.z * dt;
    
    
    // while(change_yaw < -M_PI){
    //     change_yaw += 2.0 * M_PI;
    // }
    //  while(change_yaw > M_PI){
    //     change_yaw -= 2.0 * M_PI;
    // }

    geometry_msgs::Quaternion odom_quat = tf::createQuaternionMsgFromYaw(change_yaw);

    




    

   

}



class particle{
    public:
    int id;
    double x;
    double y;
    double theta;
    double weight;
};

vector<double>weights{};
vector<particle>particles{};
int number_of_particles;



void particle_init(double x, double y , double theta, double std[])
{
    number_of_particles = 10000;
    weights.resize(number_of_particles);
    particles.resize(number_of_particles);
    double std_x,std_y,std_theta;
    std_x = std[0];
    std_y = std[1];
    std_theta = std[2];

    normal_distribution<double> dist_x(x, std_x); 
    normal_distribution<double> dist_y(y, std_y);
    normal_distribution<double> dist_theta(theta, std_theta);

    default_random_engine e;

    for(int i = 0; i < number_of_particles; i++){
     particle p;
     p.id = i;
     p.x = dist_x(e);
     p.theta = dist_y(e);
     p.weight = 1;

     particles[i] = p;
     weights[i] = p.weight;

    }

}

void prediction(double delta_t,double std_dev_pos[],double velocity,double yaw_rate)
{
    double std_x = std_dev_pos[0];
    double std_y = std_dev_pos[1];
    double std_theta = std_dev_pos[2];

    default_random_engine e;


    for(int i = 0; i <number_of_particles; i++){

        particle *p = &particles[i];
        int new_x = p->x + ((velocity/yaw_rate) *(sin(p->theta + (yaw_rate * delta_t))-sin(p->theta)));
        int new_y = p->y + ((velocity/yaw_rate) *(cos(p->theta + (yaw_rate * delta_t))-cos(p->theta)));
        int new_theta = p->theta + (yaw_rate * delta_t);

        normal_distribution<double> dist_x(new_x, std_x); 
        normal_distribution<double> dist_y(new_y, std_y);
        normal_distribution<double> dist_theta(new_theta, std_theta);

        p->x = dist_x(e);
        p->y = dist_y(e);
        p->theta = dist_theta(e);
    }
}


int main(int argc, char **argv)
{

    ros::init(argc, argv, "my_map");

    ros::NodeHandle nh;

    pub = nh.advertise<std_msgs::String>("my_chatter", 1000);

    laser_pub = nh.advertise<std_msgs::String>("laser_scan", 1000);

    ros::Subscriber sub_sensor = nh.subscribe("/scan", 1000, my_sensor_function);
    ros::Subscriber sub_odom = nh.subscribe("odom", 1000, my_odom_function);
    ros::Subscriber sub = nh.subscribe("/map", 1000, my_map_function);

    ros::spin();

    return 0;
}
